function repete3x(){
    for (let i=0; i<3; i++){
        console.log('Conexão feita com sucesso!');
    }
}

repete3x();